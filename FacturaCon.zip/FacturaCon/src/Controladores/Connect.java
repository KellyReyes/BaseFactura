/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author VIVIANA
 */
public class Connect {
    public Connection conexion;
    public Statement sentencia;
    public ResultSet resultado;
    
    private Connection con;
     public void conectar() {
        con = null;
        try {
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/Progra3BD", "postgres", "7121997cumple");
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/facturas", "root", "123456789kelly");
             //con = DriverManager.getConnection("jdbc:mysql://192.168.3.251:3306/Factura", "root", "hpurl");
            // con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/facturas", "root", "123kelly");


        } catch (SQLException ex) {
            System.out.println(ex.getMessage() + " Error de Conexion sadjsjd");
        }
        if (con != null) {
            System.out.println("Conexión Exitosa");
        }
    }
    
      public void desconectar() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Desconexión Exitosa");
            } catch (SQLException ex) {
                System.out.println("Error Al Desconectar " + ex.getMessage());
            }
        }
    }

}
     
        
 



           