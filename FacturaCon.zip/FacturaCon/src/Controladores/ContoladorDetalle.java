/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Cliente;
import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
import modelo.Producto;

/**
 *
 * @author VIVIANA
 */
public class ContoladorDetalle {

    private Connection con;
    private List<FacturaCabecera> facturaCabecera;
    private List<FacturaDetalle> facturaDetalle;
    private List<Producto> producto;

    public void conectar() {
        con = null;
        try {
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/Progra3BD", "postgres", "7121997cumple");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/facturas", "root", "123456789kelly");
            //con = DriverManager.getConnection("jdbc:mysql://192.168.3.251:3306/Factura", "root", "hpurl");
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/facturas", "root", "123kelly");
            

        } catch (SQLException ex) {
            System.out.println(ex.getMessage() + " Error de Conexion ");
        }
        if (con != null) {
            System.out.println("Conexión Exitosa");
        }
    }

    public void desconectar() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Desconexión Exitosa");
            } catch (SQLException ex) {
                System.out.println("Error Al Desconectar " + ex.getMessage());
            }
        }
    }
    
      
      public int obtenerCodigo() {
        String sql = "SELECT MAX(det_numero) FROM factura_detalle ";
        int codigo = 0;
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet res = sta.executeQuery(sql);
           // System.out.println(sql);
            while (res.next()) {
                codigo = res.getInt(1);
            }
            res.close();
            sta.close();
            desconectar();
        } catch (SQLException ex) {
            
            System.out.println("Error de Obtencion " + ex.getMessage());
        }
        return codigo + 1;
        
    }



    public void crear(FacturaDetalle p) {
        String sql = "INSERT INTO factura_detalle VALUES ( " + p.getFacturaCabecera().getIdFactura() + ", "  + p.getCantidad()+ ", "+ p.getMonto() + ", "+ p.getProducto().getIdProducto() +  ", '" + p.getFacturaCabecera().getIdFactura()+"' );";
        System.out.println(sql);

        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            System.out.println(sql);
        }
    }

    public Producto buscar(int codigo) {

        String sql = "SELECT * FROM factura_detalle WHERE factura_fact_numero =" + codigo;
        //System.out.println(sql);

        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Producto c = new Producto();
                //c.setIdCliente(reset.getInt(1));
                c.setIdProducto(reset.getInt(1));
                c.setNombre(reset.getString(2));
                c.setPrecio(reset.getDouble(3));
                c.setStock(reset.getInt(4));

                return c;
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return null;
    }

    public List<FacturaDetalle> buscarCopia(String cod) {

        List<FacturaDetalle> facdetalle = new ArrayList<FacturaDetalle>();
        String sql = "SELECT * FROM factura_detalle WHERE factura_fact_numero  ='" + cod + "';";
        System.out.println("SQL: " + sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);

            while (reset.next()) {
                FacturaDetalle facD = new FacturaDetalle();
                facD.setFacturaCabecera((FacturaCabecera) facturaCabecera);
                //facD.setProducto(producto);
                
                facD.setCantidad(reset.getInt(2));
                
                facD.setMonto(reset.getInt(3));
                facdetalle.add(facD);
                //System.out.println(cli); // aqui se imprime MUDA!                
            }

            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return facdetalle; //Que burra que es!!!
    }
    
    
     public List<FacturaDetalle> listarDetall(int codigo) {
        List<FacturaDetalle> facturaDetalle = new ArrayList();
        String sql = "SELECT * FROM  factura_detalle WHERE factura_fact_numero  =" + codigo + ";";
         System.out.println("lsta"+sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                FacturaDetalle cli = new FacturaDetalle();
               //cli.getIdFactura(reset.getInt(1));
                
                //cli.getFecha(reset.getDate(2));
              
               
                facturaDetalle.add(cli);
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return facturaDetalle;
    }
    
}
