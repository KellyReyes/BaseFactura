/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import static com.sun.webkit.perf.WCFontPerfLogger.reset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import modelo.Cliente;

/**
 *
 * @author VIVIANA
 */
public class ControladorCliente {
    
    private Connection con;
    private List<Cliente> clientes;

    public void conectar() {
        con = null;
        try {
           // con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/facturas", "root", "123456789kelly");
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/facturas", "root", "123456789kelly");
           //  con = DriverManager.getConnection("jdbc:mysql://192.168.3.251:3306/Factura", "root", "hpurl");


        } catch (SQLException ex) {
            System.out.println(ex.getMessage() + " Error de Conexion sadjsjd");
        }
        if (con != null) {
            System.out.println("Conexión Exitosa");
        }
    }
    
      public void desconectar() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Desconexión Exitosa");
            } catch (SQLException ex) {
                System.out.println("Error Al Desconectar " + ex.getMessage());
            }
        }
    }
      
      
      
      
      
      
      public int obtenerCodigo() {
        String sql = "SELECT MAX(cli_codigo) FROM \"cliente\"";
        int codigo = 0;
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet res = sta.executeQuery(sql);
            while (res.next()) {
                codigo = res.getInt(1);
            }
            res.close();
            sta.close();
            desconectar();
        } catch (SQLException ex) {
            
            System.out.println("Error de Obtencion " + ex.getMessage());
        }
        return codigo + 1;
    }

    public void crear(Cliente c) {
        String sql = "INSERT INTO clientes VALUES ( '" + c.getCedula()+"', '" + c.getNombre()+ "' , '"
                + c.getApellido()+ "', '" + c.getEmail()+ "' ,'" + c.getDireccion()+ "' ,"+c.getTelefono()+");";
        
        System.out.println(""+sql);
        
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            System.out.println(sql);
        }
    }

    public Cliente buscar(String cedula) {

        String sql = "SELECT * FROM clientes WHERE  cli_id  ='"  + cedula + "';";
        
        //System.out.println(sql);
         
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Cliente c = new Cliente();
                //c.setIdCliente(reset.getInt(1));
                c.setCedula(reset.getString(1));
                c.setNombre(reset.getString(2));
                c.setApellido(reset.getString(3));
                c.setEmail(reset.getString(4));
                c.setDireccion(reset.getString(5));
                c.setTelefono(reset.getInt(6));
                //System.out.println("cedula sy existe");
                return c;
                
            }
            System.out.println("cedula no existe");
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return null;
    }

    public void eliminar(String cedula) {
  String sql = "DELETE FROM clientes WHERE  cli_id  ='" + cedula + "';";
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }

    public void actualizar(Cliente c, String cedula) {
    String sql = "UPDATE clientes  SET   cli_id  = '" + c.getCedula()
            + "', cli_nombres = '" + c.getNombre()
            + "', cli_apellidos = '"+ c.getApellido()
            + "', cli_email = '" + c.getEmail()
            +"',cli_direccion ='"+c.getDireccion()
            + " ',cli_telefono = " +c.getTelefono()
                + " WHERE cli_id ='" + cedula + "';";
        System.out.println(sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error jjjjjj " + ex.getMessage());
        }
    }

    public List<Cliente> listar() {
        List<Cliente> clientes = new ArrayList();
        String sql = "SELECT * FROM clientes ";
        
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Cliente cli = new Cliente();
//                cli.setIdCliente(reset.getInt(1));
                cli.setCedula(reset.getString(1));
                cli.setNombre(reset.getString(2));
                cli.setApellido(reset.getString(3));
                cli.setEmail(reset.getString(4));
                cli.setDireccion(reset.getString(5));
                cli.setTelefono(reset.getInt(6));
                clientes.add(cli);
                //System.out.println(cli);
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return clientes;
    }
    
 
     public List<Cliente> buscarCopia(String cedula) {
        
        List<Cliente> cliente = new ArrayList<Cliente>();
        String sql = "SELECT * FROM clientes WHERE cli_id  LIKE '" + cedula + "%';";
        System.out.println("SQL: " + sql);                    
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            
            while (reset.next()) {                
                Cliente cli = new Cliente();                
                cli.setCedula(reset.getString(1));
                cli.setNombre(reset.getString(2));
                cli.setApellido(reset.getString(3));
                cli.setEmail(reset.getString(4));
                cli.setDireccion(reset.getString(5));
                cli.setTelefono(reset.getInt(6));                
                cliente.add(cli);
                //System.out.println(cli); // aqui se imprime MUDA!                
            }            
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return cliente; //Que burra que es!!!
    }
    
     
     public List<Cliente> buscarCopiaNombre(String nombre) {
        
        List<Cliente> cliente = new ArrayList<Cliente>();
        String sql = "SELECT * FROM clientes WHERE cli_nombres  LIKE '" + nombre + "%';";
        System.out.println("SQL: " + sql);                    
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            
            while (reset.next()) {                
                Cliente cli = new Cliente();                
                cli.setCedula(reset.getString(1));
                cli.setNombre(reset.getString(2));
                cli.setApellido(reset.getString(3));
                cli.setEmail(reset.getString(4));
                cli.setDireccion(reset.getString(5));
                cli.setTelefono(reset.getInt(6));                
                cliente.add(cli);
                //System.out.println(cli); // aqui se imprime MUDA!                
            }            
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return cliente; //Que burra que es!!!
    }
    
    
}
