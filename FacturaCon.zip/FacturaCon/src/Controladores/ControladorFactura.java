/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import modelo.Cliente;
import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
import modelo.Producto;

/**
 *
 * @author VIVIANA
 */
public class ControladorFactura {
    
   private Connection con;
   private Cliente cliente;
    private List<FacturaCabecera> facturaCabecera;
    private List<FacturaDetalle> facturaDetalle;

    public void conectar() {
        con = null;
        try {
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/Progra3BD", "postgres", "7121997cumple");
           //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/facturas", "root", "123456789kelly");
           //  con = DriverManager.getConnection("jdbc:mysql://192.168.3.251:3306/Factura", "root", "hpurl");
           con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/facturas", "root", "123kelly");


        } catch (SQLException ex) {
            System.out.println(ex.getMessage() + " Error de Conexion ");
        }
        if (con != null) {
            System.out.println("Conexión Exitosa");
        }
    }
    
      public void desconectar() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Desconexión Exitosa");
            } catch (SQLException ex) {
                System.out.println("Error Al Desconectar " + ex.getMessage());
            }
        }
    }
      
      
      
      
      
      
      public int obtenerCodigo() {
        String sql = "SELECT MAX(fact_numero) FROM factura ";
        int codigo = 0;
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet res = sta.executeQuery(sql);
           // System.out.println(sql);
            while (res.next()) {
                codigo = res.getInt(1);
            }
            res.close();
            sta.close();
            desconectar();
        } catch (SQLException ex) {
            
            System.out.println("Error de Obtencion " + ex.getMessage());
        }
        return codigo + 1;
        
    }

    public void crear (FacturaCabecera p) {
        String sql = "INSERT INTO factura VALUES ( '" + p.getIdFactura()+"', '" + p.getFecha()+ "' , "
                + p.getSubtotal() + ", " +p.getDescuento()+ ", "+p.getIva()+ ", " + p.getTotal() + ", '" + p.getCedu()+ "');";
        
                
        System.out.println(sql);
        
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            System.out.println(sql);
        }
    }

    public Producto buscar(int codigo) {

        String sql = "SELECT * FROM factura WHERE fact_numero =" + codigo;
        //System.out.println(sql);
         
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Producto c = new Producto();
                //c.setIdCliente(reset.getInt(1));
                c.setIdProducto(reset.getInt(1));
                c.setNombre(reset.getString(2));
                c.setPrecio(reset.getDouble(3));
                c.setStock(reset.getInt(4));
                
                return c;
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return null;
    }

    public void eliminar(int codigo) {
        String sql = "DELETE FROM \"cliente\" WHERE cli_codigo =" + codigo + ";";
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }

    public void actualizar(Producto c, int codigo) {
    String sql = "UPDATE producto  SET  prod_codigo = " + c.getIdProducto()
            + ",prod_nombre = '" + c.getNombre()
            + "', prod_precio = "+ c.getPrecio()
            + ", prod_stock = " + c.getStock()
            
                + " WHERE prod_codigo =" + codigo;
        System.out.println(sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error jjjjjj " + ex.getMessage());
        }
    }

    public List<FacturaCabecera> listarCab() {
        List<FacturaCabecera> facturaCabecera = new ArrayList();
        String sql = "SELECT * FROM \"cliente\" ORDER BY cli_codigo";
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                FacturaCabecera cli = new FacturaCabecera();
               //cli.getIdFactura(reset.getInt(1));
                
                //cli.getFecha(reset.getDate(2));
              
               
                facturaCabecera.add(cli);
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return facturaCabecera;
    }
    
    public void fecha (){
          java.util.Date fech = new java.util.Date(); 
         SimpleDateFormat formato = new SimpleDateFormat("dd-MM-YYYY");
    
    }
    
     
    public List<FacturaCabecera> buscarCopia(String codigo) {
        
        List<FacturaCabecera> facab = new ArrayList<FacturaCabecera>();
        String sql = "SELECT * FROM factura WHERE fact_numero LIKE '" + codigo + "%';";
            
        System.out.println("SQL: " + sql);                    
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            
            while (reset.next()) {                
                FacturaCabecera facabe=  new FacturaCabecera();                
                facabe.setIdFactura(reset.getString(1));
                facabe.setFecha(reset.getString(2));
                facabe.setSubtotal(reset.getDouble(3));
                facabe.setDescuento(reset.getDouble(4));
                facabe.setIva(reset.getDouble(5));
                facabe.setTotal(reset.getDouble(6));
                
                                
                facab.add(facabe);
                System.out.println(facabe); // aqui se imprime MUDA!                
            }            
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return facab; //Que burra que es!!!
    }
    
    
    
}



