/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import modelo.Producto;


/**
 *
 * @author VIVIANA
 */
public class ControladorProducto {
    
     private Connection con;
    private List<Producto> productos;

    public void conectar() {
        con = null;
        try {
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/Progra3BD", "postgres", "7121997cumple");
           //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/facturas", "root", "123456789kelly");
             //con = DriverManager.getConnection("jdbc:mysql://192.168.3.251:3306/Factura", "root", "hpurl");
             con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/facturas", "root", "123kelly");


        } catch (SQLException ex) {
            System.out.println(ex.getMessage() + " Error de Conexion sadjsjd");
        }
        if (con != null) {
            System.out.println("Conexión Exitosa");
        }
    }
    
      public void desconectar() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Desconexión Exitosa");
            } catch (SQLException ex) {
                System.out.println("Error Al Desconectar " + ex.getMessage());
            }
        }
    }
      
      
      
      
      
      
      public int obtenerCodigo() {
        String sql = "SELECT MAX(pro_id) FROM productos ";
        int codigo = 0;
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet res = sta.executeQuery(sql);
           // System.out.println(sql);
            while (res.next()) {
                codigo = res.getInt(1);
            }
            res.close();
            sta.close();
            desconectar();
        } catch (SQLException ex) {
            
            System.out.println("Error de Obtencion " + ex.getMessage());
        }
        return codigo + 1;
        
    }

    public void crear (Producto p) {
        String sql = "INSERT INTO productos VALUES ( " + p.getIdProducto()+", '" + p.getNombre()+ "' , "
                + p.getPrecio()+ ", " + p.getStock() +", '" + p.getCategoria() +"');";
        
        System.out.println(sql);
        
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            System.out.println(sql);
        }
    }

    public Producto buscar(int codigo) {

        String sql = "SELECT * FROM productos WHERE pro_id =" + codigo;
        //System.out.println(sql);
         
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Producto c = new Producto();
                //c.setIdCliente(reset.getInt(1));
                c.setIdProducto(reset.getInt(1));
                c.setNombre(reset.getString(2));
                c.setPrecio(reset.getDouble(3));
                c.setStock(reset.getInt(4));
                c.setCategoria(reset.getString(5));
                
                
                return c;
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return null;
    }

     public void eliminar(int codigo) {
  String sql = "DELETE FROM productos WHERE pro_id =" + codigo + ";";
  
         System.out.println("sql"+sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }

    public void actualizar(Producto c, int codigo) {
    String sql = "UPDATE productos  SET  pro_id = " + c.getIdProducto()
            + ",pro_descripcion = '" + c.getNombre()
            + "', pro_valor = "+ c.getPrecio()
            + ", pro_stock = " + c.getStock()
             + ", pro_categoria = '" + c.getCategoria()
            
                + "' WHERE pro_id =" + codigo;
        System.out.println(sql);
        try {
            conectar();
            Statement sta = con.createStatement();
            sta.executeUpdate(sql);
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error jjjjjj " + ex.getMessage());
        }
    }

    public List<Producto> listar() {
        List<Producto> productos = new ArrayList();
        String sql = "SELECT * FROM  productos ORDER BY pro_id";
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            while (reset.next()) {
                Producto cli = new Producto();
               cli.setIdProducto(reset.getInt(1));
                
                cli.setNombre(reset.getString(2));
                cli.setPrecio(reset.getDouble(3));
                cli.setStock(reset.getInt(4));
               cli.setCategoria(reset.getString(5));
                productos.add(cli);
            }
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return productos;
    }
    
    public List<Producto> buscarCopia(int codigo) {
        
        List<Producto> producto = new ArrayList<Producto>();
        String sql = "SELECT * FROM productos WHERE pro_id::text  LIKE '" + codigo + "%';";
        System.out.println("SQL: " + sql);                    
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            
            while (reset.next()) {                
                Producto prod=  new Producto();                
                prod.setIdProducto(reset.getInt(1));
                prod.setNombre(reset.getString(2));
                prod.setPrecio(reset.getDouble(3));
                prod.setStock(reset.getInt(4));
                 prod.setCategoria(reset.getString(5));
                                
                producto.add(prod);
                //System.out.println(cli); // aqui se imprime MUDA!                
            }            
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return producto; //Que burra que es!!!
    }
    
     
     public List<Producto> buscarCopiaNombre(String nombre) {
        
        List<Producto> producto = new ArrayList<Producto>();
        String sql = "SELECT * FROM productos WHERE pro_descripcion  LIKE '" + nombre + "%';";
        System.out.println("SQL: " + sql);                    
        try {
            conectar();
            Statement sta = con.createStatement();
            ResultSet reset = sta.executeQuery(sql);
            
            while (reset.next()) {                
                Producto prod = new Producto();                
                prod.setIdProducto(reset.getInt(1));
                prod.setNombre(reset.getString(2));
                prod.setPrecio(reset.getDouble(3));
                prod.setStock(reset.getInt(4)); 
                 prod.setCategoria(reset.getString(5)); 
                producto.add(prod);
                //System.out.println(cli); // aqui se imprime MUDA!                
            }            
           
            desconectar();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        return producto; //Que burra que es!!!
    }
    
    
}


