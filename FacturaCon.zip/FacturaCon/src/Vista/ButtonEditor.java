/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;

/**
 *
 * @author VIVIANA
 */
public class ButtonEditor extends DefaultCellEditor {
  protected JButton button;

  private String label;

  private boolean isPushed;

  public ButtonEditor(JCheckBox checkBox) {
    super(checkBox);
    button = new JButton("Eliminar");
    button.setOpaque(true);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
      }
    });
  }

  public Component getTableCellEditorComponent(JTable table, Object value,
      boolean isSelected, int row, int column) {
    if (isSelected) {
      button.setForeground(table.getSelectionForeground());
      button.setBackground(table.getSelectionBackground());
      
      int res = JOptionPane.showConfirmDialog(button, "¿Está seguro que desea eliminar?");        
      if(res == JOptionPane.OK_OPTION){
        DefaultTableModel modelo = (DefaultTableModel) table.getModel();
        modelo.removeRow(row);
        
      }
      
    } else {
      button.setForeground(table.getForeground());
      button.setBackground(table.getBackground());
    }
   // label = (value == null) ? "" : value.toString();
    label = "Eliminar";
    button.setText(label);
    isPushed = true;
    return button;
  }

  public Object getCellEditorValue() {
    int res = 0; 
    if (isPushed) {      
        
    }
    isPushed = false;
    return res;
  }

  public boolean stopCellEditing() {
    isPushed = false;
    return super.stopCellEditing();
  }


}
