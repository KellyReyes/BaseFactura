/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;

/**
 *
 * @author VIVIANA
 */
public class FacturaCabecera {
    
    private String fecha;
    private String idFactura;
    private double subtotal;
    private double descuento;
    private double iva;
    private double total;
    private Cliente cliente;
    private String cedu;
    
    public FacturaCabecera (){
        
        
      
        idFactura = "";
        
    }

    public FacturaCabecera(String fecha, String idFactura, double subtotal, double descuento, double iva, double total,String cedu ) {
        this.fecha = fecha;
        this.idFactura = idFactura;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.iva = iva;
        this.total = total;
        this.cliente = cliente;
        this.cedu = cedu;
    }

    

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public String getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(String idFactura) {
        this.idFactura = idFactura;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getCedu() {
        return cedu;
    }

    public void setCedu(String cedu) {
        this.cedu = cedu;
    }

    @Override
    public String toString() {
        return "FacturaCabecera{" + "fecha=" + fecha + ", idFactura=" + idFactura + ", subtotal=" + subtotal + ", descuento=" + descuento + ", iva=" + iva + ", total=" + total + ", cliente=" + cliente + ", cedu=" + cedu + '}';
    }

}