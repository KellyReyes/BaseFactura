/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author VIVIANA
 */
public class FacturaDetalle {

    private int codigodeta;
    private int cantidad;
    private double monto;
    private Producto producto;
    private FacturaCabecera facturaCabecera;



    public FacturaDetalle() {

        //odigodeta = 1;

        //monto = 0;
    }

    public FacturaDetalle(int codigodeta, int cantidad, double monto, Producto producto, FacturaCabecera facturaCabecera) {
        this.codigodeta = codigodeta;
        this.cantidad = cantidad;
        this.monto = monto;
        this.producto = producto;
        this.facturaCabecera = facturaCabecera;
    }

    public int getCodigodeta() {
        return codigodeta;
    }

    public void setCodigodeta(int codigodeta) {
        this.codigodeta = codigodeta;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public FacturaCabecera getFacturaCabecera() {
        return facturaCabecera;
    }

    public void setFacturaCabecera(FacturaCabecera facturaCabecera) {
        this.facturaCabecera = facturaCabecera;
    }

    @Override
    public String toString() {
        return "FacturaDetalle{" + "codigodeta=" + codigodeta + ", cantidad=" + cantidad + ", monto=" + monto + ", producto=" + producto + ", facturaCabecera=" + facturaCabecera + '}';
    }

    
}